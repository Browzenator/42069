/* ═══════════════════════════════════════════════════════════════════
   $SCHIZO · schizo-fx.js — max chaos FX layer
   Loaded AFTER app.js. Adds:
   - per-channel atmospheric particles
   - cursor trail of sigils
   - text scramble corruption
   - random system error toasts
   - channel-switch flash
   ═══════════════════════════════════════════════════════════════════ */
(function(){

  // ─── Cursor trail ────────────────────────────────────────────
  const trailRoot = document.getElementById('cursor-trail');
  const TRAIL_GLYPHS = ['卐','✟','✠','✞','♰','☩','⛧','◬','▲','✦','✧','✷','✺'];
  let lastTrail = 0;
  if (trailRoot) {
    document.addEventListener('mousemove', (e) => {
      const now = performance.now();
      if (now - lastTrail < 50) return;
      lastTrail = now;
      if (window.__schizo_no_stickers) return;
      const el = document.createElement('div');
      el.className = 'ct';
      el.style.left = e.clientX + 'px';
      el.style.top  = e.clientY + 'px';
      el.textContent = TRAIL_GLYPHS[Math.floor(Math.random()*TRAIL_GLYPHS.length)];
      el.style.color = Math.random() > .5 ? 'var(--accent)' : 'var(--accent2)';
      trailRoot.appendChild(el);
      setTimeout(() => el.remove(), 850);
    }, { passive: true });
  }

  // ─── Per-channel particle systems ────────────────────────────
  const cfx = document.getElementById('channel-fx');
  let cfxInterval = null;

  function clearCFX() {
    if (cfxInterval) { clearInterval(cfxInterval); cfxInterval = null; }
    if (cfx) cfx.innerHTML = '';
  }

  function spawnParticle() {
    if (!cfx) return;
    if (window.__schizo_no_stickers) return;
    const ch = document.body.getAttribute('data-channel') || 'gyrotta';
    const p = document.createElement('div');
    p.className = 'cfx-particle';
    p.style.left = (Math.random()*100) + 'vw';

    if (ch === 'snow') {
      const isWord = Math.random() > .8;
      if (isWord) {
        p.classList.add('flake');
        p.textContent = ['пропала','MISSING','-18°C','144p','02:14','失踪'][Math.floor(Math.random()*6)];
        p.style.fontSize = (10 + Math.random()*8) + 'px';
      } else {
        const s = 2 + Math.random()*4;
        p.style.width = s+'px'; p.style.height = s+'px';
      }
      p.style.animationDuration = (6 + Math.random()*8) + 's';
      p.style.animationDelay    = (-Math.random()*6) + 's';
      p.style.top = '-5vh';
    }
    else if (ch === 'khrushchevka') {
      const words = ['БЛОК-9','ЭТАЖ 7','+7°C','КВ 88','4404','ОНИ ЗАПИСАЛИ','-9°C','ЛИФТ','ANTENNA'];
      p.textContent = words[Math.floor(Math.random()*words.length)];
      p.style.animationDuration = (10 + Math.random()*10) + 's';
      p.style.animationDelay    = (-Math.random()*10) + 's';
      p.style.bottom = '-5vh';
    }
    else if (ch === 'angel') {
      const glyphs = ['✟','✞','✠','♰','☩','8','8888','✦','✧'];
      p.textContent = glyphs[Math.floor(Math.random()*glyphs.length)];
      p.style.fontSize = (18 + Math.random()*32) + 'px';
      p.style.animationDuration = (7 + Math.random()*8) + 's';
      p.style.animationDelay    = (-Math.random()*8) + 's';
      p.style.bottom = '-5vh';
    }
    else { // gyrotta
      const glyphs = ['卐','✟','◬','▲','⛧'];
      p.textContent = glyphs[Math.floor(Math.random()*glyphs.length)];
      p.style.fontSize = (22 + Math.random()*30) + 'px';
      p.style.animationDuration = (6 + Math.random()*6) + 's';
      p.style.animationDelay    = (-Math.random()*4) + 's';
      p.style.top = '-5vh';
    }

    cfx.appendChild(p);
    setTimeout(() => p.remove(), 18000);
  }

  function startCFX() {
    clearCFX();
    if (!cfx) return;
    for (let i = 0; i < 20; i++) spawnParticle();
    cfxInterval = setInterval(spawnParticle, 600);
  }

  startCFX();
  // restart on channel change
  const obs = new MutationObserver(() => startCFX());
  obs.observe(document.body, { attributes: true, attributeFilter: ['data-channel'] });

  // ─── Channel switch flash ───────────────────────────────────
  const prevSetChannel = window.setChannel;
  if (prevSetChannel) {
    window.setChannel = function(ch) {
      document.body.classList.add('ch-switching');
      setTimeout(() => document.body.classList.remove('ch-switching'), 600);
      document.body.classList.add('shake-now');
      setTimeout(() => document.body.classList.remove('shake-now'), 500);
      prevSetChannel(ch);
    };
    // re-bind buttons
    document.querySelectorAll('.ch-btn').forEach(b => {
      b.onclick = () => window.setChannel(b.dataset.ch);
    });
  }

  // ─── Text scramble corruption ───────────────────────────────
  const SCRAMBLE_CHARS = '!<>-_\\/[]{}—=+*^?#░▒▓█▄▀│┤┐└┴┬├─┼╣║╗╝╚╔╩╦╠═╬卐✟✠☩⛧◬▲一二三四五六七八九十أبجدهوزحطيك';
  function scrambleEl(el, duration) {
    if (!el || el.dataset.scrambling === '1') return;
    const original = el.dataset.original || el.textContent;
    el.dataset.original = original;
    el.dataset.scrambling = '1';
    const chars = original.split('');
    const total = duration || 600;
    const start = performance.now();
    function step(now) {
      const t = (now - start) / total;
      if (t >= 1) {
        el.textContent = original;
        el.dataset.scrambling = '0';
        return;
      }
      let out = '';
      for (let i = 0; i < chars.length; i++) {
        if (i / chars.length < t) out += chars[i];
        else if (chars[i] === ' ') out += ' ';
        else out += SCRAMBLE_CHARS[Math.floor(Math.random()*SCRAMBLE_CHARS.length)];
      }
      el.textContent = out;
      requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }

  // pick targets: section titles, codex numbers, phase names
  function getScrambleTargets() {
    return document.querySelectorAll('.section-title, .codex-num, .phase-name, .hero-tag, .final-title');
  }

  // periodic scramble
  setInterval(() => {
    if (window.__schizo_no_popups && window.__schizo_no_stickers) return;
    const els = getScrambleTargets();
    if (!els.length) return;
    const pick = els[Math.floor(Math.random()*els.length)];
    scrambleEl(pick, 500 + Math.random()*600);
  }, 4200);

  // scramble on hover
  document.addEventListener('mouseover', (e) => {
    const t = e.target.closest && e.target.closest('.section-title, .codex-num, .phase-name');
    if (t) scrambleEl(t, 380);
  });

  // ─── System error toasts ────────────────────────────────────
  const sysRoot = document.getElementById('sys-errors');
  const SYS_MSGS = [
    'PACKET LOSS: 81%',
    'MEMORY VIOLATION 0x4404',
    'CODEC NOT FOUND · UNREG HYPERCAM',
    'WALLET FINGERPRINT LOGGED',
    'SIGNAL DEGRADING · RE-INVOKE 8888',
    'BUFFER UNDERRUN · GYROTTA.ZAO',
    'CASE 4404-CCЭ · UPDATED',
    'FILE 4404 · CHECKSUM FAIL',
    'STREAM CORRUPTED · STAY',
    'BLOCK-9 ANTENNA · DOWN',
    'RECORDING — HYPERCAM 2 — 144p',
    'TIMESTAMP: 03:33:33 AM',
    'PERMISSION DENIED · file open anyway',
    'مفقود · СИГНАЛ · 失踪',
    'PHANTOM DETECTED · KEYS LOGGED',
  ];

  function spawnSysError() {
    if (!sysRoot || window.__schizo_no_popups) return;
    const el = document.createElement('div');
    el.className = 'sys-error';
    el.textContent = SYS_MSGS[Math.floor(Math.random()*SYS_MSGS.length)];
    el.style.top  = (5 + Math.random()*80) + 'vh';
    el.style.left = (Math.random() > .5 ? 'auto' : (4 + Math.random()*30) + 'vw');
    el.style.right = el.style.left === 'auto' ? (4 + Math.random()*30) + 'vw' : 'auto';
    sysRoot.appendChild(el);
    setTimeout(() => el.remove(), 6500);
  }
  setInterval(spawnSysError, 3200);
  setTimeout(spawnSysError, 1200);

  // ─── Random body shake bursts ───────────────────────────────
  setInterval(() => {
    if (window.__schizo_no_popups) return;
    if (Math.random() > .82) {
      document.body.classList.add('shake-now');
      setTimeout(() => document.body.classList.remove('shake-now'), 500);
    }
  }, 5000);

  // ─── Scroll-driven chaos amplification ──────────────────────
  let lastScroll = 0, scrollVel = 0;
  window.addEventListener('scroll', () => {
    const now = performance.now();
    const dy = Math.abs(window.scrollY - lastScroll);
    lastScroll = window.scrollY;
    scrollVel = Math.min(3, scrollVel + dy*0.01);
  }, { passive: true });
  setInterval(() => {
    if (scrollVel > 0.05) {
      const v = 1 + Math.min(2, scrollVel*0.4);
      document.documentElement.style.setProperty('--chaos', v.toFixed(2));
      scrollVel *= 0.85;
    } else {
      // ease back to base
      const cur = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--chaos')) || 1;
      if (Math.abs(cur - 1) > 0.02) {
        document.documentElement.style.setProperty('--chaos', (cur + (1-cur)*0.2).toFixed(2));
      }
    }
  }, 120);

})();
