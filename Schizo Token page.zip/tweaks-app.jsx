// tweaks-app.jsx — $SCHIZO Tweaks panel
const { useState, useEffect } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "channel": "gyrotta",
  "chaos": 1,
  "rotAmt": 1,
  "grain": 0.35,
  "scan": 0.35,
  "strobe": true,
  "popups": true,
  "stickers": true,
  "ticker": "$SCHIZO",
  "ca": "SoLaNa1111111111111111111111111111111111111"
}/*EDITMODE-END*/;

function SchizoTweaks() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // Apply on mount + whenever values change
  useEffect(() => { if (window.__schizo) window.__schizo.setChannel(t.channel); }, [t.channel]);
  useEffect(() => { if (window.__schizo) window.__schizo.setChaos(t.chaos); }, [t.chaos]);
  useEffect(() => { if (window.__schizo) window.__schizo.setRot(t.rotAmt); }, [t.rotAmt]);
  useEffect(() => { if (window.__schizo) window.__schizo.setGrain(t.grain); }, [t.grain]);
  useEffect(() => { if (window.__schizo) window.__schizo.setScan(t.scan); }, [t.scan]);
  useEffect(() => { if (window.__schizo) window.__schizo.setStrobe(t.strobe); }, [t.strobe]);
  useEffect(() => { if (window.__schizo) window.__schizo.setPopups(t.popups); }, [t.popups]);
  useEffect(() => { if (window.__schizo) window.__schizo.setStickers(t.stickers); }, [t.stickers]);
  useEffect(() => { if (window.__schizo) window.__schizo.setTicker(t.ticker); }, [t.ticker]);
  useEffect(() => { if (window.__schizo) window.__schizo.setCA(t.ca); }, [t.ca]);

  return (
    <TweaksPanel title="Tweaks · $SCHIZO">
      <TweakSection label="Lore channel" />
      <TweakSelect
        label="Channel"
        value={t.channel}
        options={[
          { value: 'gyrotta',      label: '01 · GYROTTA (canonical)' },
          { value: 'snow',         label: '02 · SNOW GIRL (dossier)' },
          { value: 'khrushchevka', label: '03 · KHRUSHCHEVKA (concrete)' },
          { value: 'angel',        label: '04 · 8888 ANGEL (pink)' },
        ]}
        onChange={(v) => setTweak('channel', v)}
      />

      <TweakSection label="Chaos engine" />
      <TweakSlider label="Chaos amount" value={t.chaos} min={0} max={2} step={0.05}
                   onChange={(v) => setTweak('chaos', v)} />
      <TweakSlider label="Card rotation" value={t.rotAmt} min={0} max={2} step={0.1}
                   onChange={(v) => setTweak('rotAmt', v)} />
      <TweakSlider label="Film grain" value={t.grain} min={0} max={1} step={0.05}
                   onChange={(v) => setTweak('grain', v)} />
      <TweakSlider label="Scanlines" value={t.scan} min={0} max={1} step={0.05}
                   onChange={(v) => setTweak('scan', v)} />

      <TweakSection label="FX toggles" />
      <TweakToggle label="Strobe overlay"  value={t.strobe}   onChange={(v) => setTweak('strobe', v)} />
      <TweakToggle label="Floating stickers" value={t.stickers} onChange={(v) => setTweak('stickers', v)} />
      <TweakToggle label="Intrusive popups" value={t.popups}   onChange={(v) => setTweak('popups', v)} />

      <TweakSection label="Token" />
      <TweakText  label="Ticker" value={t.ticker} onChange={(v) => setTweak('ticker', v)} />
      <TweakText  label="Contract address" value={t.ca} onChange={(v) => setTweak('ca', v)} />

      <TweakSection label="Quick actions" />
      <TweakButton label="Trigger SCHIZO MODE" onClick={() => window.triggerStorm && window.triggerStorm()} />
      <TweakButton label="Reduce flashing" onClick={() => window.reduceFlashing && window.reduceFlashing()} />
    </TweaksPanel>
  );
}

ReactDOM.createRoot(document.getElementById('tweaks-root')).render(<SchizoTweaks />);
