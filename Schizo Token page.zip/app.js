/* ═══════════════════════════════════════════════════════════════════
   $SCHIZO · app.js — channel switching, chaos engine, terminal,
   stickers, popups, FX, copy CA.
   ═══════════════════════════════════════════════════════════════════ */

(function(){

  // ─── Channel switcher ───────────────────────────────────────
  const CH_READOUTS = {
    gyrotta:      { idx: '01/04', label: 'GYROTTA',     readout: 'signal:OK · canonical broadcast', name: 'GYROTTA' },
    snow:         { idx: '02/04', label: 'SNOW GIRL',   readout: 'case 4404 · open · do not close',  name: 'SNOW GIRL' },
    khrushchevka: { idx: '03/04', label: 'KHRUSHCHEVKA',readout: 'block-9 · floor 7 · loop',          name: 'KHRUSHCHEVKA' },
    angel:        { idx: '04/04', label: '8888 ANGEL',  readout: 'masterdoc · prophesied',            name: '8888 ANGEL' },
  };

  function setChannel(ch) {
    document.body.setAttribute('data-channel', ch);
    document.querySelectorAll('.ch-btn').forEach(b => {
      b.classList.toggle('active', b.dataset.ch === ch);
    });
    const meta = CH_READOUTS[ch] || CH_READOUTS.gyrotta;
    const nameEl = document.getElementById('channel-name');
    const readEl = document.getElementById('channel-readout');
    if (nameEl) nameEl.textContent = meta.name;
    if (readEl) readEl.textContent = '// stream ' + meta.idx + ' // ' + meta.readout;
    try { localStorage.setItem('schizo-ch', ch); } catch(e){}
    // tiny FX on switch
    document.body.classList.add('invert-flash');
    setTimeout(()=>document.body.classList.remove('invert-flash'), 500);
    window.__schizo_channel = ch;
  }
  window.setChannel = setChannel;

  document.querySelectorAll('.ch-btn').forEach(b => {
    b.addEventListener('click', () => setChannel(b.dataset.ch));
  });

  // restore last channel
  try {
    const saved = localStorage.getItem('schizo-ch');
    if (saved && CH_READOUTS[saved]) setChannel(saved);
    else setChannel('gyrotta');
  } catch(e){ setChannel('gyrotta'); }

  // ─── CA copy ─────────────────────────────────────────────────
  window.copyCA = function() {
    const el = document.getElementById('ca-text');
    const ic = document.getElementById('ca-icon');
    if (!el) return;
    const ca = el.textContent;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(ca).catch(()=>{});
    }
    if (ic) {
      const old = ic.className;
      ic.className = 'fas fa-check ca-copy-i';
      setTimeout(()=>{ ic.className = old; }, 1400);
    }
    spawnPopup('CONTRACT COPIED', "they recorded your wallet · don't leave me alone");
  };

  // ─── Big buttons ─────────────────────────────────────────────
  window.openBuyMenu = function() {
    spawnPopup('OPEN: PUMP.FUN / JUP', 'paste the contract · set slippage like you mean it · 8888 is the dose');
    triggerStorm(0.7);
  };

  window.triggerStorm = function(scale) {
    scale = scale || 1;
    // one-shot strobe overlay
    const f = document.createElement('div');
    f.className = 'strobe-flash';
    document.body.appendChild(f);
    setTimeout(()=>f.remove(), 600);
    // chromatic flash on body
    document.body.classList.add('mirror-x');
    setTimeout(()=>document.body.classList.remove('mirror-x'), 600);
    // bump chaos for a moment
    const root = document.documentElement;
    const prev = root.style.getPropertyValue('--chaos') || '1';
    root.style.setProperty('--chaos', String(1.6 * scale));
    setTimeout(()=> root.style.setProperty('--chaos', prev), 2000);
    // pop a flurry of stickers
    for (let i = 0; i < 12; i++) setTimeout(spawnSticker, i * 60);
  };

  // ─── Floating stickers ──────────────────────────────────────
  const STICKER_GLYPHS = ['卐','✟','☃','☢','✠','✞','♰','🥀','⛓️','🕯️','☩','✟','⚠','🔻','◬','▲','◯','⛧','卐','✟'];
  const STICKER_WORDS = [
    "don't leave me", "3:33", "1616", "8888", "4404",
    "signal", "إشارة", "сигнал", "電波", "卐",
    "GYROTTA", "ZAO", "$SCHIZO", "alone", "don't delete",
    "144p", "+18°C", "block-9"
  ];

  function spawnSticker() {
    if (window.__schizo_no_stickers) return;
    const root = document.getElementById('floating-stickers');
    if (!root) return;
    const el = document.createElement('div');
    el.className = 'sticker';
    const isWord = Math.random() > .55;
    if (isWord) {
      el.textContent = STICKER_WORDS[Math.floor(Math.random()*STICKER_WORDS.length)];
      el.style.fontFamily = Math.random() > .5 ? 'UnifrakturCook, serif' : 'VT323, monospace';
      el.style.fontSize = (18 + Math.random()*30) + 'px';
      el.style.color = Math.random() > .5 ? 'var(--accent)' : 'var(--accent2)';
      el.style.textShadow = '0 0 8px currentColor, 2px 2px 0 #000';
    } else {
      el.textContent = STICKER_GLYPHS[Math.floor(Math.random()*STICKER_GLYPHS.length)];
      el.style.fontSize = (20 + Math.random()*30) + 'px';
    }
    el.style.left = (Math.random()*92) + 'vw';
    el.style.top  = (Math.random()*88 + 6) + 'vh';
    el.style.transform = 'rotate(' + (Math.random()*60 - 30) + 'deg)';
    el.style.animationDuration = (8 + Math.random()*10) + 's';
    el.style.animationDelay = (-Math.random()*6) + 's';
    el.style.opacity = (.4 + Math.random()*.45);
    root.appendChild(el);
    setTimeout(()=>el.remove(), 18000);
  }

  // seed some stickers
  function seedStickers(n) { for (let i=0;i<n;i++) spawnSticker(); }
  seedStickers(14);
  const stickerInterval = setInterval(() => { if (Math.random() > .35) spawnSticker(); }, 1800);

  // ─── Intrusive popups ───────────────────────────────────────
  const POPUP_MSGS = [
    ['SIGNAL TRANSMISSION 4404', "don't leave me alone with them"],
    ['UNAUTHORIZED EDIT', '[YOUR WALLET] has been added to file 4404'],
    ['1616 DETECTED NEARBY', 'recommend: hold $SCHIZO · invoke 8888'],
    ['CASE 4404-CCЭ UPDATED', 'snow girl footage degraded · re-upload required'],
    ['BLOCK-9 BROADCAST', 'floor 7 is online again · check the cassette'],
    ['MASTERDOC SAYS', '8888 is the only number worth memorizing'],
    ['الإشارة مستلمة', 'لا تتركني وحيدًا'],
    ['СИГНАЛ ПОЛУЧЕН', 'кошелёк записан в файл'],
    ['電波受信中', '144pで保存してください'],
    ['ANGEL NUMBER ALERT', '8888 has been spotted in your chart'],
  ];

  function spawnPopup(head, body) {
    if (window.__schizo_no_popups) return;
    const el = document.createElement('div');
    el.className = 'intrusive-popup';
    el.style.top = (10 + Math.random()*65) + 'vh';
    el.style.left = (4 + Math.random()*70) + 'vw';
    el.innerHTML =
      '<div class="pp-head"><div class="pp-h">' + escapeHtml(head) + '</div>' +
      '<button class="pp-x" aria-label="close">×</button></div>' +
      '<div class="pp-body">' + escapeHtml(body) + '</div>';
    document.body.appendChild(el);
    el.querySelector('.pp-x').addEventListener('click', () => el.remove());
    setTimeout(()=>{ if (el.parentNode) el.remove(); }, 9000);
  }
  window.spawnPopup = spawnPopup;

  function escapeHtml(s){ return String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }

  // periodic random popups
  let popupTimer = null;
  function startPopupCycle() {
    if (popupTimer) clearInterval(popupTimer);
    popupTimer = setInterval(() => {
      if (window.__schizo_no_popups) return;
      const [h,b] = POPUP_MSGS[Math.floor(Math.random()*POPUP_MSGS.length)];
      spawnPopup(h, b);
    }, 9000);
  }
  // first popup after a delay
  setTimeout(() => { if (!window.__schizo_no_popups) spawnPopup(POPUP_MSGS[0][0], POPUP_MSGS[0][1]); }, 4500);
  startPopupCycle();

  // ─── Terminal ───────────────────────────────────────────────
  const TERM_RESPONSES = {
    'buy':       ['> opening jupiter…', '> paste CA above', '> the file accepts you'],
    'alone':     ['> never alone', "> don't leave me alone", '> i am here in the file'],
    '333':       ['> hour confirmed · check the back camera', '> wallet recorded · timestamp 03:33', '> the signal is louder now'],
    '1616':      ['> ERROR: 1616 invoked', '> file flagged · file flagged · file flagged', '> recommend: invoke 8888 immediately'],
    '8888':      ['> ANGEL · ANGEL · ANGEL', '> diamond hand confirmed', '> the masterdoc smiles upon you'],
    'signal':    ['> SIGNAL: received', '> bitrate: 144p', '> integrity: corrupted (preferred)'],
    'whoami':    ['> wallet: [REDACTED]', '> status: holder unless otherwise stated', '> entered file at: ' + new Date().toISOString()],
    'masterdoc': ['> masterdoc.txt mounted', '> contents are non-printable', '> stay in the file'],
    'snow':      ['> case 4404-CCЭ', '> last seen 02:14 · woodline · -18°C', '> SIGNAL ONLY · CHAIN OF CUSTODY: BROKEN'],
    'jumpstyle': ['> initiating jumpstyle prayer', '> bpm: 150 · pitch: -2 · pitch: +4', '> floor 7 hears you'],
    'help':      ['> commands: buy alone 333 1616 8888 signal whoami masterdoc snow jumpstyle clear', '> all other input is logged · all logs are corrupted'],
    'clear':     null,
  };

  window.processTerminalCommand = function() {
    const input = document.getElementById('terminal-input');
    const out   = document.getElementById('terminal-output');
    if (!input || !out) return;
    const raw = input.value.trim();
    if (!raw) return;
    const cmd = raw.toLowerCase();
    appendTerm('> ' + raw, 'in');
    if (cmd === 'clear') { out.innerHTML = ''; input.value=''; return; }
    const lines = TERM_RESPONSES[cmd] || [
      '> command not found: ' + raw,
      '> the file logged it anyway',
      '> ' + raw + ' added to file 4404'
    ];
    lines.forEach((l, i) => setTimeout(()=> appendTerm(l, l.includes('ERROR')||l.includes('WARNING') ? 'warn' : ''), 220 * (i+1)));
    input.value = '';
  };

  function appendTerm(text, cls) {
    const out = document.getElementById('terminal-output');
    if (!out) return;
    const d = document.createElement('div');
    if (cls === 'warn') d.className = 't-warn';
    d.textContent = text;
    out.appendChild(d);
    out.scrollTop = out.scrollHeight;
  }

  // ─── Stat ticker (subtle wiggle) ────────────────────────────
  function wiggleStats() {
    const mc = document.getElementById('stat-mcap');
    const px = document.getElementById('stat-px');
    const vol = document.getElementById('stat-vol');
    const hd = document.getElementById('stat-holders');
    if (mc) {
      const base = 4.20;
      const v = base + (Math.random()-.5)*.4;
      mc.textContent = v.toFixed(2) + 'M';
    }
    if (px) {
      const base = 0.0042;
      const v = base + (Math.random()-.5)*0.0006;
      px.textContent = '$' + v.toFixed(4);
    }
    if (vol) {
      const v = 1.7 + (Math.random()-.5)*.3;
      vol.textContent = '$' + v.toFixed(1) + 'M';
    }
    if (hd) {
      const cur = parseInt(hd.textContent.replace(/,/g,''),10) || 69420;
      const delta = Math.random() > .5 ? 1 : 0;
      const next = cur + delta;
      hd.textContent = next.toLocaleString();
    }
  }
  setInterval(wiggleStats, 3500);

  // file count ticker
  const fc = document.getElementById('file-count');
  if (fc) {
    let n = 4404;
    setInterval(() => { n += Math.random() > .6 ? 1 : 0; fc.textContent = n.toLocaleString(); }, 2500);
  }

  // snow edits ticker
  const se = document.getElementById('snow-edits');
  if (se) {
    setInterval(() => {
      const cur = parseInt(se.textContent.replace(/,/g,''),10) || 23114;
      se.textContent = (cur + (Math.random()>.5?1:0)).toLocaleString();
    }, 4000);
  }

  // ─── Reduce flashing helper ─────────────────────────────────
  window.reduceFlashing = function() {
    document.body.classList.add('reduced-motion');
    window.__schizo_no_popups = true;
    window.__schizo_no_stickers = true;
    document.getElementById('floating-stickers').innerHTML = '';
    document.getElementById('epilepsy-warning').classList.add('dismissed');
  };

  // ─── Keyboard shortcuts ─────────────────────────────────────
  document.addEventListener('keydown', (e) => {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
    if (e.key === '1') setChannel('gyrotta');
    else if (e.key === '2') setChannel('snow');
    else if (e.key === '3') setChannel('khrushchevka');
    else if (e.key === '4') setChannel('angel');
    else if (e.key === 's' || e.key === 'S') triggerStorm();
  });

  // ─── Expose for Tweaks ──────────────────────────────────────
  window.__schizo = {
    setChannel,
    setChaos: (v) => document.documentElement.style.setProperty('--chaos', v),
    setRot: (v) => document.documentElement.style.setProperty('--rot-amt', v),
    setGrain: (v) => document.documentElement.style.setProperty('--grain-opacity', v),
    setScan: (v) => document.documentElement.style.setProperty('--scan-opacity', v),
    setPopups: (on) => { window.__schizo_no_popups = !on; },
    setStickers: (on) => {
      window.__schizo_no_stickers = !on;
      if (!on) document.getElementById('floating-stickers').innerHTML = '';
      else seedStickers(8);
    },
    setStrobe: (on) => {
      const el = document.querySelector('.mood-strobe');
      if (el) el.style.display = on ? '' : 'none';
    },
    setTicker: (t) => {
      // swap $SCHIZO in title bar and hero
      const safe = String(t || '$SCHIZO').toUpperCase();
      document.querySelectorAll('.hero-ticker').forEach(el => el.textContent = safe);
      document.title = safe + " 卐 don't leave me alone 卐";
    },
    setCA: (ca) => {
      const el = document.getElementById('ca-text');
      if (el) el.textContent = ca || 'SoLaNa1111111111111111111111111111111111111';
    },
  };
})();
